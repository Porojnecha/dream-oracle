#if defined(OPENSSL_NO_ASM)
# include "./ui_no-asm.h"
#else
# include "./ui_asm.h"
#endif
